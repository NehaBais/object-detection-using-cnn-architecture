# aiHub > 2022-08-21 2:04pm
https://universe.roboflow.com/pxrksuhn/aihub-aizqc

Provided by a Roboflow user
License: CC BY 4.0

